import sys, json, math, time
from collections import Counter
import gspread
from google.oauth2.service_account import Credentials
print("="*56)
print("  FINAL INVESTIGATION — win-rate + whipsaw deep-dive")
print("="*56)
cfg = json.load(open('sheets_config.json'))
creds = Credentials.from_service_account_file('google_credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc = gspread.authorize(creds)
all_rows=[]; header=None
months=list(cfg.keys())
for mi,month in enumerate(months):
    sid = cfg[month].get('post_analysis')
    if not sid: continue
    for attempt in range(4):
        try:
            vals = gc.open_by_key(sid).sheet1.get_all_values()
            if not vals: break
            if header is None: header=vals[0]
            cnt=0
            for r in vals[1:]:
                if r and any(c.strip() for c in r): all_rows.append(r); cnt+=1
            print(f"  {month}: {cnt} rows OK")
            break
        except Exception as e:
            wait=15*(attempt+1)
            print(f"  {month} attempt {attempt+1} failed ({str(e)[:50]}) — waiting {wait}s")
            time.sleep(wait)
    time.sleep(8)  # gentle pacing between sheets
if header is None:
    print("NO DATA"); sys.exit(0)
idx={h.strip():i for i,h in enumerate(header)}
def col(row,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(row): return d
    v=row[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in ('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if (math.isnan(f) or math.isinf(f)) else f
    except: return None
def istrue(v): return str(v).strip() in ('1','TRUE','True','true','1.0')
n=len(all_rows)
print(f"\n>>> TOTAL rows loaded: {n} <<<")

# ===== 1. CLASSIFICATION + WIN-RATE =====
tp=sl=whip=neither=0
for r in all_rows:
    t=istrue(col(r,'TP10_Hit')); s=istrue(col(r,'SL_Hit_D5'))
    if t and s: whip+=1
    elif t: tp+=1
    elif s: sl+=1
    else: neither+=1
print(f"\n########## 1. CLASSIFICATION (n={n}) ##########")
print(f"  TP10 only:   {tp:>4} ({100*tp/n:.1f}%)")
print(f"  SL only:     {sl:>4} ({100*sl/n:.1f}%)")
print(f"  WHIPSAW:     {whip:>4} ({100*whip/n:.1f}%)")
print(f"  Neither:     {neither:>4} ({100*neither/n:.1f}%)")
resolved=tp+sl+whip
print(f"\n  win-rate, whipsaw=win:  {100*(tp+whip)/resolved:.1f}%  (n={resolved})")
print(f"  win-rate, whipsaw=loss: {100*tp/resolved:.1f}%")
print(f"  win-rate, whipsaw excluded: {100*tp/(tp+sl):.1f}%  (n={tp+sl})")

# ===== 2. WHIPSAW DEEP-DIVE =====
print(f"\n########## 2. WHIPSAW DEEP-DIVE ##########")
whip_rows=[r for r in all_rows if istrue(col(r,'TP10_Hit')) and istrue(col(r,'SL_Hit_D5'))]
print(f"  whipsaw rows: {len(whip_rows)}")
# distribution by month + score_version
wm=Counter(col(r,'ScanDate','?')[:7] for r in whip_rows)
print(f"  by month: {dict(sorted(wm.items()))}")
# how deep did they drop / rise?
print(f"\n  --- per-whipsaw detail (first 20): MaxDrop%, BestDay, D1-D5 High vs SL trigger ---")
for r in whip_rows[:20]:
    tk=col(r,'Ticker','?'); sd=col(r,'ScanDate','?')
    sp=fnum(col(r,'ScanPrice')); md=col(r,'MaxDrop%','?'); bd=col(r,'BestDay','?')
    highs=[fnum(col(r,f"D{i}_High")) for i in range(1,6)]
    sl_trigger=sp*1.10 if sp else None
    first_sl_day=None
    for i,h in enumerate(highs,1):
        if h is not None and sl_trigger and h>=sl_trigger:
            first_sl_day=i; break
    print(f"    {tk:<7}{sd}  ScanPx={sp}  MaxDrop%={md}  TP_BestDay={bd}  SL_first_day=D{first_sl_day}")

# ===== 3. did SL happen BEFORE or AFTER TP? (timing) =====
print(f"\n  --- WHIPSAW timing: which hit first, TP or SL? ---")
sl_first=tp_first=same_day=unknown=0
for r in whip_rows:
    sp=fnum(col(r,'ScanPrice'))
    if not sp: unknown+=1; continue
    bd=fnum(col(r,'BestDay'))  # day of min low (TP)
    highs=[fnum(col(r,f"D{i}_High")) for i in range(1,6)]
    sl_day=None
    for i,h in enumerate(highs,1):
        if h is not None and h>=sp*1.10: sl_day=i; break
    if bd is None or sl_day is None: unknown+=1
    elif sl_day<bd: sl_first+=1
    elif bd<sl_day: tp_first+=1
    else: same_day+=1
print(f"    SL hit first (before TP day):  {sl_first}")
print(f"    TP hit first (before SL day):  {tp_first}")
print(f"    same day (cannot resolve):     {same_day}")
print(f"    unknown:                       {unknown}")
print(f"  NOTE: same-day cases need intraday data — daily OHLC cannot resolve them.")

# ===== 4. clean correlations vs MaxDrop% =====
print(f"\n########## 3. CORRELATIONS vs MaxDrop% (nan-filtered) ##########")
def corr(xs,ys):
    p=[(x,y) for x,y in zip(xs,ys) if x is not None and y is not None]
    if len(p)<10: return None,len(p)
    k=len(p); mx=sum(a for a,_ in p)/k; my=sum(b for _,b in p)/k
    cov=sum((a-mx)*(b-my) for a,b in p)
    vx=sum((a-mx)**2 for a,_ in p); vy=sum((b-my)**2 for _,b in p)
    if vx==0 or vy==0: return None,k
    return cov/(vx**0.5*vy**0.5),k
maxdrop=[fnum(col(r,'MaxDrop%')) for r in all_rows]
metrics=['Score','MxV','RunUp','ATRX','RSI','REL_VOL','ScanChange%','TypicalPriceDist','Float%','Gap','PriceToHigh']
print(f"  {'metric':<20}{'r vs MaxDrop%':>16}    n")
ranked=[]
for met in metrics:
    if met not in idx: continue
    xs=[fnum(col(r,met)) for r in all_rows]
    c,k=corr(xs,maxdrop)
    if c is not None: ranked.append((abs(c),c,met,k))
for ac,c,met,k in sorted(ranked,reverse=True):
    print(f"  {met:<20}{c:>+16.3f}    {k}")

# ===== 5. MaxDrop% distribution =====
md=[x for x in maxdrop if x is not None]; md.sort()
print(f"\n########## 4. MaxDrop% DISTRIBUTION (n={len(md)}) ##########")
print(f"  min={md[0]:.1f}  p10={md[len(md)//10]:.1f}  p25={md[len(md)//4]:.1f}  median={md[len(md)//2]:.1f}  p75={md[3*len(md)//4]:.1f}  max={md[-1]:.1f}")
print(f"  mean={sum(md)/len(md):.2f}")
neg10=sum(1 for x in md if x<=-10)
print(f"  rows that dropped >=10%: {neg10}/{len(md)} ({100*neg10/len(md):.1f}%)")

print("\n=== FINAL INVESTIGATION DONE ===")
