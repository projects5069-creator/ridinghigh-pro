echo "=== RECON FINAL: exact code structure before editing ==="
echo ""
echo "--- utils.py: imports + constants at top (lines 40-60) ---"
sed -n '40,60p' utils.py
echo ""
echo "--- utils.py: FULL calculate_stats — exact text (lines 377-446) ---"
sed -n '377,446p' utils.py
echo ""
echo "--- utils.py: __all__ export list if any ---"
grep -n "__all__" utils.py 2>/dev/null
echo ""
echo "--- dashboard.py: post_analysis KPI block — EXACT (lines 2356-2378) ---"
sed -n '2356,2378p' dashboard.py
echo ""
echo "--- dashboard.py: how utils functions are imported ---"
grep -n "from utils\|import utils\|calculate_stats" dashboard.py 2>/dev/null | head -8
echo ""
echo "--- which function contains line 2360 (the post-analysis page) ---"
awk 'NR<=2360 && /^def /{name=$0; line=NR} END{print "  enclosing def:", name, "(line "line")"}' dashboard.py
echo ""
echo "--- py_compile baseline check (must pass BEFORE we edit) ---"
python3 -m py_compile utils.py && echo "  utils.py compiles OK" || echo "  utils.py COMPILE ERROR"
python3 -m py_compile dashboard.py && echo "  dashboard.py compiles OK" || echo "  dashboard.py COMPILE ERROR"
echo ""
echo "=== RECON FINAL DONE ==="
