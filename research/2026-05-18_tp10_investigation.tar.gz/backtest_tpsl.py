import sys, json, math, time
import gspread
from google.oauth2.service_account import Credentials
print("="*60)
print("  TP/SL BACKTEST — fully-settled rows, day-by-day simulation")
print("="*60)
cfg=json.load(open('sheets_config.json'))
creds=Credentials.from_service_account_file('google_credentials.json',scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc=gspread.authorize(creds)
all_rows=[];header=None
for month in cfg:
    sid=cfg[month].get('post_analysis')
    if not sid: continue
    for a in range(5):
        try:
            vals=gc.open_by_key(sid).sheet1.get_all_values()
            if not vals: break
            if header is None: header=vals[0]
            for r in vals[1:]:
                if r and any(x.strip() for x in r): all_rows.append(r)
            print(f"  {month}: loaded"); break
        except Exception as e:
            w=20*(a+1); print(f"  {month} 429 — wait {w}s"); time.sleep(w)
    time.sleep(12)
idx={h.strip():i for i,h in enumerate(header)}
def col(r,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(r): return d
    v=r[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if(math.isnan(f) or math.isinf(f)) else f
    except: return None

# fully-settled = all 5 days have a valid Low
def is_full(r): return all(fnum(col(r,f"D{i}_Low")) is not None for i in range(1,6))
fully=[r for r in all_rows if is_full(r) and fnum(col(r,'ScanPrice'))]
print(f"\n>>> fully-settled rows for backtest: {len(fully)} <<<")

def simulate(r, tp_pct, sl_pct):
    """Day-by-day. SHORT position. TP = price drops tp_pct. SL = price rises sl_pct.
       Returns: 'WIN','LOSS','WHIP_SAMEDAY','OPEN'."""
    sp=fnum(col(r,'ScanPrice'))
    tp_price=sp*(1-tp_pct/100.0)
    sl_price=sp*(1+sl_pct/100.0)
    for i in range(1,6):
        lo=fnum(col(r,f"D{i}_Low")); hi=fnum(col(r,f"D{i}_High"))
        if lo is None or hi is None: continue
        tp_hit = lo<=tp_price
        sl_hit = hi>=sl_price
        if tp_hit and sl_hit: return 'WHIP'      # same day, unresolvable
        if sl_hit: return 'LOSS'                  # SL first (conservative: SL before TP)
        if tp_hit: return 'WIN'
    return 'OPEN'  # neither in 5 days → close at D5 close

def pnl_if_open(r):
    """For OPEN positions: PnL = short entry vs D5 close."""
    sp=fnum(col(r,'ScanPrice')); d5c=fnum(col(r,'D5_Close'))
    if sp and d5c: return (sp-d5c)/sp*100.0
    return None

scenarios=[(10,10),(10,12),(10,15),(10,20),(12,15),(12,20),(15,20),(15,25),(10,999)]
print(f"\n{'TP%':>5}{'SL%':>6}{'WIN':>6}{'LOSS':>6}{'WHIP':>6}{'OPEN':>6}{'win-rate*':>11}{'avg PnL%/trade':>16}")
print("  (win-rate* = wins/(wins+losses), whipsaw & open excluded from rate)")
print("  "+"-"*56)
for tp_pct,sl_pct in scenarios:
    w=l=wh=op=0
    pnl_sum=0.0; pnl_n=0
    for r in fully:
        res=simulate(r,tp_pct,sl_pct)
        if res=='WIN':
            w+=1; pnl_sum+=tp_pct; pnl_n+=1          # +TP%
        elif res=='LOSS':
            l+=1; pnl_sum-=sl_pct; pnl_n+=1          # -SL%
        elif res=='WHIP':
            wh+=1                                     # excluded — unresolvable
        else:
            op+=1
            p=pnl_if_open(r)
            if p is not None: pnl_sum+=p; pnl_n+=1   # close at D5
    rate = 100*w/(w+l) if (w+l) else 0
    avg = pnl_sum/pnl_n if pnl_n else 0
    sl_label = "∞" if sl_pct==999 else str(sl_pct)
    print(f"  {tp_pct:>3}{sl_label:>6}{w:>6}{l:>6}{wh:>6}{op:>6}{rate:>10.1f}%{avg:>15.2f}%")

print(f"\n  NOTE: 'avg PnL%/trade' counts WIN=+TP%, LOSS=-SL%, OPEN=actual D5 close PnL,")
print(f"        WHIP excluded (cannot resolve intraday order). Before costs/slippage/borrow.")
print(f"  NOTE: SL=∞ scenario = no stop-loss at all (pure 5-day hold to TP or D5 close).")
print("\n=== BACKTEST DONE ===")
