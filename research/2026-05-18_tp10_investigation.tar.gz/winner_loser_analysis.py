import json, math
SNAP="post_analysis_snapshot.json"
data=json.load(open(SNAP))
header=data['header']; all_rows=data['rows']
idx={h.strip():i for i,h in enumerate(header)}
def col(r,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(r): return d
    v=r[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if(math.isnan(f) or math.isinf(f)) else f
    except: return None
def is_full(r): return all(fnum(col(r,f"D{i}_Low")) is not None for i in range(1,6))
fully=[r for r in all_rows if is_full(r) and fnum(col(r,'ScanPrice'))]
print("="*62)
print("  WINNER vs LOSER ANALYSIS — TP=10/SL=10, fully-settled rows")
print("="*62)

# classify with day-by-day sim (SL-first = loss), 10/10
def outcome(r):
    sp=fnum(col(r,'ScanPrice')); tpx=sp*0.9; slx=sp*1.1
    for i in range(1,6):
        lo=fnum(col(r,f"D{i}_Low")); hi=fnum(col(r,f"D{i}_High"))
        if lo is None or hi is None: continue
        t=lo<=tpx; s=hi>=slx
        if t and s: return 'WHIP'
        if s: return 'LOSS'
        if t: return 'WIN'
    return 'OPEN'
winners=[r for r in fully if outcome(r)=='WIN']
losers =[r for r in fully if outcome(r)=='LOSS']
whips  =[r for r in fully if outcome(r)=='WHIP']
opens  =[r for r in fully if outcome(r)=='OPEN']
print(f"\n  WIN={len(winners)}  LOSS={len(losers)}  WHIP={len(whips)}  OPEN={len(opens)}")

metrics=['Score','MxV','RunUp','ATRX','RSI','REL_VOL','ScanChange%','TypicalPriceDist',
         'Float%','Gap','PriceToHigh','Volume','MarketCap','DayRunUp%','ScanCount']
def stats(rows,m):
    vals=sorted(v for v in (fnum(col(r,m)) for r in rows) if v is not None)
    if not vals: return None
    n=len(vals)
    return {'n':n,'mean':sum(vals)/n,'median':vals[n//2],'min':vals[0],'max':vals[-1]}

print(f"\n  {'metric':<18}{'WIN mean':>11}{'LOSS mean':>11}{'WIN med':>10}{'LOSS med':>10}{'separation':>12}")
print("  "+"-"*70)
seps=[]
for m in metrics:
    if m not in idx: continue
    w=stats(winners,m); l=stats(losers,m)
    if not w or not l: continue
    # separation: difference in means, normalized by pooled spread
    allv=sorted(v for v in (fnum(col(r,m)) for r in fully) if v is not None)
    spread=(allv[-1]-allv[0]) or 1
    sep=(w['mean']-l['mean'])/spread
    seps.append((abs(sep),sep,m,w,l))
for asep,sep,m,w,l in sorted(seps,reverse=True):
    print(f"  {m:<18}{w['mean']:>11.2f}{l['mean']:>11.2f}{w['median']:>10.2f}{l['median']:>10.2f}{sep:>+12.3f}")

# === for the TOP 3 separating metrics, find a filter threshold ===
print(f"\n########## FILTER SEARCH — top 3 separating metrics ##########")
top3=[m for _,_,m,_,_ in sorted(seps,reverse=True)[:3]]
for m in top3:
    print(f"\n  --- {m} ---")
    wv=[fnum(col(r,m)) for r in winners]; wv=[v for v in wv if v is not None]
    lv=[fnum(col(r,m)) for r in losers]; lv=[v for v in lv if v is not None]
    allv=sorted(set([fnum(col(r,m)) for r in fully if fnum(col(r,m)) is not None]))
    best=None
    for thr in allv:
        # try both directions: keep rows >= thr, and keep rows <= thr
        for direction in ('>=','<='):
            if direction=='>=':
                kw=sum(1 for v in wv if v>=thr); kl=sum(1 for v in lv if v>=thr)
            else:
                kw=sum(1 for v in wv if v<=thr); kl=sum(1 for v in lv if v<=thr)
            kept=kw+kl
            if kept<15: continue  # need enough rows to be meaningful
            wr=kw/kept
            if best is None or wr>best[0]:
                best=(wr,thr,direction,kw,kl,kept)
    if best:
        wr,thr,d,kw,kl,kept=best
        base_wr=len(winners)/(len(winners)+len(losers))
        print(f"    baseline win-rate (no filter): {100*base_wr:.1f}%  ({len(winners)}W/{len(losers)}L)")
        print(f"    BEST filter: keep rows where {m} {d} {thr:.2f}")
        print(f"      → {kw}W / {kl}L kept = {100*wr:.1f}% win-rate  (n={kept})")
        print(f"      → improvement: {100*(wr-base_wr):+.1f} percentage points")

print("\n=== ANALYSIS DONE ===")
