import sys, json
from collections import Counter
try:
    import gspread
    from google.oauth2.service_account import Credentials
except Exception as e:
    print(f"IMPORT FAIL: {e}"); sys.exit(0)
try:
    cfg = json.load(open('sheets_config.json'))
except Exception as e:
    print(f"sheets_config.json FAIL: {e}"); sys.exit(0)
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
try:
    creds = Credentials.from_service_account_file('google_credentials.json', scopes=SCOPES)
    gc = gspread.authorize(creds)
except Exception as e:
    print(f"AUTH FAIL: {e}"); sys.exit(0)
all_rows = []; header = None
for month, sheets in cfg.items():
    sid = sheets.get('post_analysis')
    if not sid: continue
    try:
        ws = gc.open_by_key(sid).sheet1
        vals = ws.get_all_values()
        if not vals: continue
        if header is None: header = vals[0]
        for r in vals[1:]:
            if r and any(c.strip() for c in r):
                all_rows.append((month, r))
        print(f"  {month}/post_analysis: {len(vals)-1} rows")
    except Exception as e:
        print(f"  {month}/post_analysis ERROR: {e}")
if header is None:
    print("NO DATA FOUND"); sys.exit(0)
print(f"\nTOTAL rows across all months: {len(all_rows)}")
print(f"\n--- HEADER ({len(header)} cols) ---")
for i,h in enumerate(header): print(f"  [{i}] {h}")
idx = {h.strip(): i for i,h in enumerate(header)}
def col(row, name, default=None):
    i = idx.get(name)
    if i is None or i >= len(row): return default
    v = row[i].strip(); return v if v else default
def fnum(v):
    if v is None: return None
    try: return float(str(v).replace('%','').replace(',','').replace('$',''))
    except: return None
dates = Counter()
for m,r in all_rows:
    d = col(r,'ScanDate') or 'NO_DATE'
    dates[d[:10]] += 1
print(f"\n--- ScanDate distribution ({len(dates)} distinct days) ---")
for d in sorted(dates): print(f"  {d}: {dates[d]}")
tp_col = 'TP10_Hit' if 'TP10_Hit' in idx else None
sl_col = 'SL_Hit_D5' if 'SL_Hit_D5' in idx else None
status_col = 'Status' if 'Status' in idx else None
print(f"\n--- Classification cols: TP10_Hit={tp_col is not None}, SL_Hit_D5={sl_col is not None}, Status={status_col is not None} ---")
tp_hits=sl_hits=whip=neither=0; status_counts=Counter()
for m,r in all_rows:
    tp = str(col(r,tp_col,'')).strip() in ('1','TRUE','True','true')
    sl = str(col(r,sl_col,'')).strip() in ('1','TRUE','True','true')
    if tp and sl: whip+=1
    elif tp: tp_hits+=1
    elif sl: sl_hits+=1
    else: neither+=1
    if status_col: status_counts[col(r,status_col,'NONE')]+=1
n=len(all_rows)
print(f"  TP only:        {tp_hits} ({100*tp_hits/n:.1f}%)")
print(f"  SL only:        {sl_hits} ({100*sl_hits/n:.1f}%)")
print(f"  WHIPSAW (both): {whip} ({100*whip/n:.1f}%)")
print(f"  Neither:        {neither} ({100*neither/n:.1f}%)")
if status_col: print(f"  Status breakdown: {dict(status_counts)}")
metrics = ['Score','MxV_calc','RunUp_calc','ATRX_calc','RSI','REL_VOL_calc','ScanChange%','TypicalPriceDist_calc','Float','RealFloat_M']
def corr(xs, ys):
    pairs=[(x,y) for x,y in zip(xs,ys) if x is not None and y is not None]
    if len(pairs)<10: return None,len(pairs)
    k=len(pairs); sx=sum(p[0] for p in pairs); sy=sum(p[1] for p in pairs)
    mx=sx/k; my=sy/k
    cov=sum((p[0]-mx)*(p[1]-my) for p in pairs)
    vx=sum((p[0]-mx)**2 for p in pairs); vy=sum((p[1]-my)**2 for p in pairs)
    if vx==0 or vy==0: return None,k
    return cov/(vx**0.5*vy**0.5), k
maxdrop=[fnum(col(r,'MaxDrop%')) for m,r in all_rows]
tp_bin=[1.0 if str(col(r,tp_col,'')).strip() in ('1','TRUE','True','true') else 0.0 for m,r in all_rows]
print(f"\n--- Correlations (metric vs outcome) ---")
print(f"  {'metric':<24} {'vs MaxDrop%':>14} {'vs TP10_Hit':>14}   n")
for met in metrics:
    if met not in idx:
        print(f"  {met:<24} {'(col missing)':>14}"); continue
    xs=[fnum(col(r,met)) for m,r in all_rows]
    c1,n1=corr(xs,maxdrop); c2,n2=corr(xs,tp_bin)
    s1=f"{c1:+.3f}" if c1 is not None else "n/a"
    s2=f"{c2:+.3f}" if c2 is not None else "n/a"
    print(f"  {met:<24} {s1:>14} {s2:>14}   {n1}")
md=[x for x in maxdrop if x is not None]
if md:
    md.sort()
    print(f"\n--- MaxDrop% distribution (n={len(md)}) ---")
    print(f"  min={md[0]:.1f}  p25={md[len(md)//4]:.1f}  median={md[len(md)//2]:.1f}  p75={md[3*len(md)//4]:.1f}  max={md[-1]:.1f}")
    print(f"  mean={sum(md)/len(md):.2f}")
print("\n=== RECON 3 DONE ===")
