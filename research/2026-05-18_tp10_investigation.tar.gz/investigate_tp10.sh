echo "╔══════════════════════════════════════════════╗"
echo "║  TP10_Hit ROOT-CAUSE INVESTIGATION — B1+B4    ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "########## B1: MaxDrop% computation source ##########"
echo "--- where MaxDrop% is ASSIGNED (non-archive) ---"
grep -rn "MaxDrop%\|max_drop" --include="*.py" . 2>/dev/null | grep -v "/research/" | grep -v "project_sync" | grep -v "גיבוי" | grep -v "/backups/" | grep -v recon | grep -v investigate | grep -iE "=|\.at\[|stats\[" | head -30
echo ""
echo "--- post_analysis_collector.py: how ohlc dict is built (D0 included?) ---"
grep -n "D0_Low\|D1_Low\|ohlc\[\|ohlc\.get\|ohlc =\|ohlc\.update\|_Low\b" post_analysis_collector.py 2>/dev/null | head -40
echo ""
echo "--- post_analysis_collector.py lines 400-460 (calculate_stats call context) ---"
sed -n '400,460p' post_analysis_collector.py 2>/dev/null
echo ""
echo "--- backfill_ohlc.py lines 30-115 (how it builds ohlc + calls calculate_stats) ---"
sed -n '30,115p' backfill_ohlc.py 2>/dev/null
echo ""
echo "########## B4: git history of the classification code ##########"
echo "--- git log: utils.py calculate_stats region ---"
git log --oneline -15 -- utils.py 2>&1 | head -15
echo ""
echo "--- git log: backfill_ohlc.py ---"
git log --oneline -15 -- backfill_ohlc.py 2>&1 | head -15
echo ""
echo "--- git log: post_analysis_collector.py ---"
git log --oneline -10 -- post_analysis_collector.py 2>&1 | head -10
echo ""
echo "--- git blame: the nan-filter line + min line + TP10 line in utils.py ---"
LINE_FILTER=$(grep -n "is not None" utils.py | grep -i "D{i}_Low\|Low" | head -1 | cut -d: -f1)
echo "nan-filter detected near line: $LINE_FILTER"
git blame -L 417,442 utils.py 2>&1 | head -30
echo ""
echo "=== B1+B4 DONE ==="
