echo "=== RECON 5: TP10_Hit classification code ==="
echo ""
echo "--- commit 3f4f95d ---"
git log -1 --format='%H | %ci | %s' 3f4f95d 2>&1 | head -2
echo ""
echo "--- which files mention TP10_Hit ---"
grep -rln "TP10_Hit\|TP10" --include="*.py" . 2>/dev/null | grep -v recon | head -20
echo ""
echo "--- TP10_Hit / MaxDrop assignment lines (with file:line) ---"
grep -rn "TP10_Hit\|MaxDrop\|max_drop\|calculate_max_drop" --include="*.py" . 2>/dev/null | grep -v recon4 | grep -v recon3 | head -40
echo ""
echo "--- post_analysis_collector.py: TP10/MaxDrop context ---"
grep -n "TP10\|MaxDrop\|max_drop\|D1_Low\|D5_Low\|min_low\|0.9\|0.90" post_analysis_collector.py 2>/dev/null | head -40
echo ""
echo "--- enrich_post_analysis.py: TP10 context ---"
grep -n "TP10\|MaxDrop\|max_drop\|IntraDay_TP10\|0.9\|0.90\|nan\|isna\|fillna" enrich_post_analysis.py 2>/dev/null | head -40
echo ""
echo "--- formulas.calculate_max_drop full body ---"
sed -n '287,325p' formulas.py
echo ""
echo "--- backfill_ohlc.py: head + how it fills D1-D5 ---"
grep -n "D1_\|D5_\|Low\|TP10\|MaxDrop\|fill\|nan" backfill_ohlc.py 2>/dev/null | head -30
echo ""
echo "=== RECON 5 DONE ==="
