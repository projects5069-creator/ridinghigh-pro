import json, collections
from utils import classify_trade
d = json.load(open("post_analysis_snapshot.json"))
ix = {h.strip(): i for i, h in enumerate(d["header"])}
def c(r, n):
    i = ix.get(n)
    if i is None or i >= len(r): return None
    v = r[i].strip()
    return v if v else None
def fn(v):
    if v is None: return None
    s = str(v).replace("%","").replace(",","").replace("$","").strip()
    if s.lower() in ("nan","none","","n/a","#n/a","inf","-inf"): return None
    try: return float(s)
    except: return None
res = collections.Counter()
for r in d["rows"]:
    sp = fn(c(r, "ScanPrice"))
    ohlc = {f"D{i}_{k}": fn(c(r, f"D{i}_{k}")) for i in range(1,6) for k in ("High","Low")}
    res[classify_trade(sp, ohlc)] += 1
w, l = res["WIN"], res["LOSS"]
print("CLASSIFY:", dict(res))
print("CLEAN WIN-RATE: %.1f%% (%dW / %dL)" % (100*w/(w+l) if w+l else 0, w, l))
print("FLAGS: WHIPSAW=%d  NO_TOUCH=%d  PENDING=%d" % (res["WHIPSAW"], res["NO_TOUCH"], res["PENDING"]))
