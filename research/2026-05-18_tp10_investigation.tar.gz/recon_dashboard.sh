echo "=== RECON: where the 81% win-rate is displayed/computed ==="
echo ""
echo "--- dashboard.py: win rate / winrate computation lines ---"
grep -n "win_rate\|winrate\|Win Rate\|win-rate\|TP10_Hit\b" dashboard.py 2>/dev/null | head -50
echo ""
echo "--- dashboard.py: the post-analysis win-rate KPI block (around line 2360-2410) ---"
sed -n '2358,2412p' dashboard.py 2>/dev/null
echo ""
echo "--- dashboard.py: section 3 win-rate block (around 3445-3475) ---"
sed -n '3445,3475p' dashboard.py 2>/dev/null
echo ""
echo "--- does a 'RealisticOutcome' or day-by-day sim already exist anywhere? ---"
grep -rn "RealisticOutcome\|realistic\|day_by_day\|SL_first\|sl_first\|simulate" --include='*.py' . 2>/dev/null | grep -v '/backups/' | grep -v 'גיבוי' | grep -v '/research/' | grep -v recon | grep -v backtest | grep -v winner_loser | head -15
echo ""
echo "--- utils.py: end of calculate_stats + what follows (lines 443-475) ---"
sed -n '443,475p' utils.py 2>/dev/null
echo ""
echo "--- post_analysis schema: are D1-D5 High/Low all in the sheet? (header check) ---"
head -1 /dev/null
python3 -c "
import json
d=json.load(open('post_analysis_snapshot.json'))
h=[c.strip() for c in d['header']]
need=[f'D{i}_{k}' for i in range(1,6) for k in ('High','Low')]
print('  D1-D5 High/Low columns present:', all(c in h for c in need))
print('  missing:', [c for c in need if c not in h])
print('  TP10_Hit index:', h.index('TP10_Hit') if 'TP10_Hit' in h else 'MISSING')
"
echo ""
echo "=== RECON DONE ==="
