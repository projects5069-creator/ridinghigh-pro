echo "=== RECON 6: locate TP10_Hit computation ==="
echo ""
echo "--- does post_analysis_collector.py exist? ---"
ls -la post_analysis_collector.py 2>&1
ls -la *collector*.py 2>&1
echo ""
echo "--- ALL files: where TP10_Hit is ASSIGNED (= or .at or [) ---"
grep -rn "TP10_Hit" --include="*.py" . 2>/dev/null | grep -v "/research/" | grep -v "project_sync" | grep -v "recon"
echo ""
echo "--- enrich_post_analysis.py: lines 120-200 (TP10 region) ---"
sed -n '120,200p' enrich_post_analysis.py 2>/dev/null
echo ""
echo "--- auto_scanner.py: TP10_Hit + MaxDrop + min_low context ---"
grep -n "TP10_Hit\|MaxDrop\|min_low\|D1_Low\|D5_Low\|calculate_max_drop" auto_scanner.py 2>/dev/null
echo ""
echo "--- search for min( over D-lows anywhere ---"
grep -rn "min_low\|D._Low\|min(\[" --include="*.py" . 2>/dev/null | grep -v "/research/" | grep -v "project_sync" | grep -v recon | grep -iE "low|drop|min_low" | head -30
echo ""
echo "=== RECON 6 DONE ==="
