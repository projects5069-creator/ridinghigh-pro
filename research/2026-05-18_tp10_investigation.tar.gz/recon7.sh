echo "=== RECON 7: calculate_stats full body ==="
echo ""
echo "--- utils.py: calculate_stats (lines 377-450) ---"
sed -n '377,450p' utils.py
echo ""
echo "--- TP_THRESHOLD_FRAC / SL_THRESHOLD_FRAC definition ---"
grep -rn "TP_THRESHOLD_FRAC\|SL_THRESHOLD_FRAC\|TP_THRESHOLD_PCT" utils.py config.py 2>/dev/null | grep -v "min_low" | head -10
echo ""
echo "--- who calls calculate_stats ---"
grep -rn "calculate_stats" --include="*.py" . 2>/dev/null | grep -v "/research/" | grep -v "project_sync" | grep -v "גיבוי" | grep -v recon
echo ""
echo "=== RECON 7 DONE ==="
