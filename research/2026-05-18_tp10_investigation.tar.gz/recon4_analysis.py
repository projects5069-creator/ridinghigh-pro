import sys, json, math
from collections import Counter
import gspread
from google.oauth2.service_account import Credentials
cfg = json.load(open('sheets_config.json'))
creds = Credentials.from_service_account_file('google_credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc = gspread.authorize(creds)
all_rows=[]; header=None
for month, sheets in cfg.items():
    sid = sheets.get('post_analysis')
    if not sid: continue
    try:
        vals = gc.open_by_key(sid).sheet1.get_all_values()
        if not vals: continue
        if header is None: header=vals[0]
        for r in vals[1:]:
            if r and any(c.strip() for c in r): all_rows.append(r)
    except Exception as e:
        print(f"  {month} ERROR: {e}")
idx={h.strip():i for i,h in enumerate(header)}
def col(row,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(row): return d
    v=row[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in ('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s)
        return None if (math.isnan(f) or math.isinf(f)) else f
    except: return None
def istrue(v): return str(v).strip() in ('1','TRUE','True','true')
n=len(all_rows)
print(f"\nTOTAL rows: {n}")

# === THE KEY BUG CHECK: MaxDrop% vs TP10_Hit consistency ===
print(f"\n--- BUG CHECK: MaxDrop% <= -10% but TP10_Hit not set ---")
md_le10=0; md_le10_tp0=0; tp1_total=0; bad_examples=[]
for r in all_rows:
    md=fnum(col(r,'MaxDrop%')); tp=istrue(col(r,'TP10_Hit'))
    if tp: tp1_total+=1
    if md is not None and md<=-10:
        md_le10+=1
        if not tp:
            md_le10_tp0+=1
            if len(bad_examples)<8:
                bad_examples.append((col(r,'Ticker'),col(r,'ScanDate'),md,col(r,'TP10_Hit')))
print(f"  rows with MaxDrop% <= -10%:           {md_le10}")
print(f"  of those, TP10_Hit NOT set (THE BUG): {md_le10_tp0}")
print(f"  rows with TP10_Hit set (total):       {tp1_total}")
print(f"  examples [ticker, date, MaxDrop%, TP10_Hit raw value]:")
for e in bad_examples: print(f"    {e}")

# also check IntraDay_TP10 (alternative TP column)
print(f"\n--- IntraDay_TP10 column check ---")
itp=Counter()
for r in all_rows: itp[col(r,'IntraDay_TP10','EMPTY')]+=1
print(f"  IntraDay_TP10 value distribution: {dict(itp)}")

# === split by 3f4f95d date (2026-05-07 = Day 3 area, use ScanDate cutoff) ===
CUTOFF='2026-05-07'
print(f"\n--- Split by ScanDate cutoff {CUTOFF} (3f4f95d live-price fix) ---")
for label,test in [('BEFORE cutoff (stale-price era)',lambda d: d<CUTOFF),('ON/AFTER cutoff (live-price era)',lambda d: d>=CUTOFF)]:
    sub=[r for r in all_rows if col(r,'ScanDate','') and test(col(r,'ScanDate')[:10])]
    if not sub: 
        print(f"  {label}: 0 rows"); continue
    tp=sum(1 for r in sub if istrue(col(r,'TP10_Hit')))
    sl=sum(1 for r in sub if istrue(col(r,'SL_Hit_D5')))
    mds=[fnum(col(r,'MaxDrop%')) for r in sub]; mds=[x for x in mds if x is not None]
    mdmed=sorted(mds)[len(mds)//2] if mds else None
    print(f"  {label}: n={len(sub)}  TP10_Hit={tp} ({100*tp/len(sub):.1f}%)  SL_Hit={sl} ({100*sl/len(sub):.1f}%)  MaxDrop%_median={mdmed}")

# === correlations, nan-filtered, with Float% ===
def corr(xs,ys):
    p=[(x,y) for x,y in zip(xs,ys) if x is not None and y is not None]
    if len(p)<10: return None,len(p)
    k=len(p); mx=sum(a for a,_ in p)/k; my=sum(b for _,b in p)/k
    cov=sum((a-mx)*(b-my) for a,b in p)
    vx=sum((a-mx)**2 for a,_ in p); vy=sum((b-my)**2 for _,b in p)
    if vx==0 or vy==0: return None,k
    return cov/(vx**0.5*vy**0.5),k
maxdrop=[fnum(col(r,'MaxDrop%')) for r in all_rows]
tp_bin=[1.0 if istrue(col(r,'TP10_Hit')) else 0.0 for r in all_rows]
metrics=['Score','MxV','RunUp','ATRX','RSI','REL_VOL','ScanChange%','TypicalPriceDist','Float%','RealFloat_M','PriceToHigh','Gap']
print(f"\n--- Correlations (nan-filtered) ---")
print(f"  {'metric':<22}{'vs MaxDrop%':>14}{'vs TP10_Hit':>14}    n")
for met in metrics:
    if met not in idx:
        print(f"  {met:<22}{'(missing)':>14}"); continue
    xs=[fnum(col(r,met)) for r in all_rows]
    c1,n1=corr(xs,maxdrop); c2,n2=corr(xs,tp_bin)
    s1=f"{c1:+.3f}" if c1 is not None else "n/a"
    s2=f"{c2:+.3f}" if c2 is not None else "n/a"
    print(f"  {met:<22}{s1:>14}{s2:>14}    {n1}")
md=[x for x in maxdrop if x is not None]; md.sort()
print(f"\n--- MaxDrop% distribution (nan-filtered, n={len(md)}) ---")
print(f"  min={md[0]:.1f}  p25={md[len(md)//4]:.1f}  median={md[len(md)//2]:.1f}  p75={md[3*len(md)//4]:.1f}  max={md[-1]:.1f}  mean={sum(md)/len(md):.2f}")
print("\n=== RECON 4 DONE ===")
