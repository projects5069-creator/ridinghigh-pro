import sys, json, math, time
from collections import Counter
import gspread
from google.oauth2.service_account import Credentials
print("="*58)
print("  MATURITY VERIFICATION — clean win-rate on settled rows")
print("="*58)
cfg = json.load(open('sheets_config.json'))
creds = Credentials.from_service_account_file('google_credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc = gspread.authorize(creds)
all_rows=[]; header=None
for month in cfg:
    sid=cfg[month].get('post_analysis')
    if not sid: continue
    for attempt in range(5):
        try:
            vals=gc.open_by_key(sid).sheet1.get_all_values()
            if not vals: break
            if header is None: header=vals[0]
            c=0
            for r in vals[1:]:
                if r and any(x.strip() for x in r): all_rows.append(r); c+=1
            print(f"  {month}: {c} rows OK")
            break
        except Exception as e:
            w=20*(attempt+1)
            print(f"  {month} attempt {attempt+1} 429 — waiting {w}s")
            time.sleep(w)
    time.sleep(12)
if header is None:
    print("NO DATA"); sys.exit(0)
idx={h.strip():i for i,h in enumerate(header)}
def col(row,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(row): return d
    v=row[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in ('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if(math.isnan(f) or math.isinf(f)) else f
    except: return None
def istrue(v): return str(v).strip() in ('1','TRUE','True','true','1.0')
n=len(all_rows)
print(f"\n>>> TOTAL rows: {n} <<<")

# ===== maturity: how many of D1-D5 OHLC are present per row =====
def maturity(r):
    days_present=0
    for i in range(1,6):
        if fnum(col(r,f"D{i}_Low")) is not None: days_present+=1
    return days_present

print(f"\n########## 1. ROW MATURITY (D1-D5 lows present) ##########")
mat=Counter(maturity(r) for r in all_rows)
for d in sorted(mat):
    print(f"  {d}/5 days present: {mat[d]} rows")
fully=[r for r in all_rows if maturity(r)==5]
partial=[r for r in all_rows if 0<maturity(r)<5]
empty=[r for r in all_rows if maturity(r)==0]
print(f"\n  FULLY settled (5/5):   {len(fully)}")
print(f"  PARTIALLY settled:     {len(partial)}")
print(f"  NO D1-D5 data at all:  {len(empty)}")

print(f"\n  --- maturity by scan-month ---")
for mo in sorted(set(col(r,'ScanDate','?')[:7] for r in all_rows)):
    sub=[r for r in all_rows if col(r,'ScanDate','?')[:7]==mo]
    f5=sum(1 for r in sub if maturity(r)==5)
    print(f"    {mo}: {len(sub)} rows, {f5} fully settled")

def classify(rows,label):
    tp=sl=whip=neither=0
    for r in rows:
        t=istrue(col(r,'TP10_Hit')); s=istrue(col(r,'SL_Hit_D5'))
        if t and s: whip+=1
        elif t: tp+=1
        elif s: sl+=1
        else: neither+=1
    k=len(rows)
    if k==0:
        print(f"\n  {label}: 0 rows"); return
    print(f"\n  {label} (n={k}):")
    print(f"    TP only={tp} ({100*tp/k:.1f}%)  SL only={sl} ({100*sl/k:.1f}%)  WHIP={whip} ({100*whip/k:.1f}%)  Neither={neither} ({100*neither/k:.1f}%)")
    res=tp+sl+whip
    if res:
        print(f"    win-rate whip=win: {100*(tp+whip)/res:.1f}%   whip=loss: {100*tp/res:.1f}%   whip-excl: {100*tp/(tp+sl) if tp+sl else 0:.1f}%")

print(f"\n########## 2. WIN-RATE BY MATURITY ##########")
classify(all_rows,"ALL rows")
classify(fully,"FULLY SETTLED only")
classify(partial,"PARTIALLY settled")

print(f"\n########## 3. WHIPSAW TIMING (fully-settled only) ##########")
whip_f=[r for r in fully if istrue(col(r,'TP10_Hit')) and istrue(col(r,'SL_Hit_D5'))]
sl_first=tp_first=same=unk=0
for r in whip_f:
    sp=fnum(col(r,'ScanPrice')); bd=fnum(col(r,'BestDay'))
    highs=[fnum(col(r,f"D{i}_High")) for i in range(1,6)]
    sld=None
    for i,h in enumerate(highs,1):
        if h is not None and sp and h>=sp*1.10: sld=i; break
    if bd is None or sld is None: unk+=1
    elif sld<bd: sl_first+=1
    elif bd<sld: tp_first+=1
    else: same+=1
print(f"  whipsaw (fully-settled): {len(whip_f)}")
print(f"    SL hit first:  {sl_first}  (realistic LOSS — stopped out before bottom)")
print(f"    TP hit first:  {tp_first}  (realistic WIN)")
print(f"    same day:      {same}  (unresolvable w/ daily OHLC)")
print(f"    unknown:       {unk}")
if len(whip_f):
    real_loss=sl_first; real_win=tp_first
    print(f"\n  >>> REALISTIC win-rate on fully-settled, treating SL-first whipsaw as loss:")
    tp_only=sum(1 for r in fully if istrue(col(r,'TP10_Hit')) and not istrue(col(r,'SL_Hit_D5')))
    sl_only=sum(1 for r in fully if istrue(col(r,'SL_Hit_D5')) and not istrue(col(r,'TP10_Hit')))
    wins=tp_only+tp_first
    losses=sl_only+sl_first
    decided=wins+losses
    if decided:
        print(f"      wins={wins} (TP-only {tp_only} + TP-first whip {tp_first})")
        print(f"      losses={losses} (SL-only {sl_only} + SL-first whip {sl_first})")
        print(f"      same-day whip unresolved: {same}")
        print(f"      REALISTIC win-rate (decided only) = {100*wins/decided:.1f}%  (n={decided})")

print("\n=== MATURITY CHECK DONE ===")
