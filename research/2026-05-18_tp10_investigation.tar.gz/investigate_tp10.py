import sys, json, math
print("\n" + "="*50)
print("  TP10_Hit INVESTIGATION — B2+B3+B5+B6 (Python)")
print("="*50)
import gspread
from google.oauth2.service_account import Credentials
cfg = json.load(open('sheets_config.json'))
creds = Credentials.from_service_account_file('google_credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc = gspread.authorize(creds)
all_rows=[]; header=None
for month, sheets in cfg.items():
    sid = sheets.get('post_analysis')
    if not sid: continue
    try:
        vals = gc.open_by_key(sid).sheet1.get_all_values()
        if not vals: continue
        if header is None: header=vals[0]
        for r in vals[1:]:
            if r and any(c.strip() for c in r): all_rows.append(r)
    except Exception as e:
        print(f"  {month} ERROR: {e}")
idx={h.strip():i for i,h in enumerate(header)}
def raw(row,name):
    i=idx.get(name)
    if i is None or i>=len(row): return None
    return row[i]
def col(row,name,d=None):
    v=raw(row,name)
    if v is None: return d
    v=v.strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in ('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if (math.isnan(f) or math.isinf(f)) else f
    except: return None
def istrue(v): return str(v).strip() in ('1','TRUE','True','true','1.0')

# identify suspect rows: MaxDrop% <= -10 but TP10_Hit not true
suspects=[]
for r in all_rows:
    md=fnum(col(r,'MaxDrop%')); tp=istrue(col(r,'TP10_Hit'))
    if md is not None and md<=-10 and not tp:
        suspects.append(r)
print(f"\n>>> SUSPECT ROWS (MaxDrop%<=-10 AND TP10_Hit not set): {len(suspects)} <<<")

# ===== B5: distribution of suspects by date + score_version =====
from collections import Counter
print(f"\n########## B5: suspect distribution ##########")
by_month=Counter(); by_sv=Counter(); by_date=Counter()
for r in suspects:
    d=col(r,'ScanDate','?')[:7]; by_month[d]+=1
    by_sv[col(r,'score_version','MISSING')]+=1
    by_date[col(r,'ScanDate','?')[:10]]+=1
print(f"  by month: {dict(sorted(by_month.items()))}")
print(f"  by score_version: {dict(by_sv)}")
print(f"  date range of suspects: {min(by_date)} -> {max(by_date)}")
# compare: non-suspect TP10=1 rows distribution
tp1=[r for r in all_rows if istrue(col(r,'TP10_Hit'))]
tp1_month=Counter(col(r,'ScanDate','?')[:7] for r in tp1)
print(f"  for contrast — TP10_Hit=1 rows by month: {dict(sorted(tp1_month.items()))}")

# ===== B6 + B2: forensic dump of 12 suspect rows, RAW values =====
print(f"\n########## B2+B6: forensic dump (raw cell values) ##########")
dcols=['D0_Open','D0_High','D0_Low','D0_Close','D1_Open','D1_High','D1_Low','D1_Close',
       'D2_Low','D3_Low','D4_Low','D5_Low']
sample=suspects[:12]
for r in sample:
    tk=col(r,'Ticker','?'); sd=col(r,'ScanDate','?'); sp=col(r,'ScanPrice','?')
    md=col(r,'MaxDrop%','?'); tp=raw(r,'TP10_Hit'); bd=col(r,'BestDay','?')
    af=col(r,'audit_flag',''); sv=col(r,'score_version','')
    print(f"\n  [{tk} {sd}] ScanPrice={sp} MaxDrop%={md} TP10_Hit=raw'{tp}' BestDay={bd} audit_flag='{af}' sv='{sv}'")
    parts=[]
    for c in dcols:
        v=raw(r,c)
        parts.append(f"{c}={v!r}")
    print(f"    {' '.join(parts)}")

# ===== B3: re-run calculate_stats LIVE on suspect OHLC, compare =====
print(f"\n########## B3: LIVE re-run of calculate_stats vs sheet value ##########")
try:
    from utils import calculate_stats
    print("  calculate_stats imported OK")
except Exception as e:
    print(f"  IMPORT FAIL: {e}"); calculate_stats=None
if calculate_stats:
    print(f"  {'Ticker':<8}{'Date':<12}{'sheet_TP10':>11}{'recomputed':>12}{'sheet_MD%':>11}{'recomp_MD%':>12}  verdict")
    agree=disagree=err=0
    for r in suspects[:30]:
        tk=col(r,'Ticker','?'); sd=col(r,'ScanDate','?')
        sp=fnum(col(r,'ScanPrice'))
        ohlc={}
        for i in range(1,6):
            for k in ('Open','High','Low','Close'):
                ohlc[f"D{i}_{k}"]=fnum(col(r,f"D{i}_{k}"))
        try:
            st=calculate_stats(sp, ohlc) if sp else None
            if st is None:
                print(f"  {tk:<8}{sd:<12}{'?':>11}{'NO_SCANPRICE':>12}"); err+=1; continue
            rc_tp=st.get('TP10_Hit'); rc_md=st.get('MaxDrop%')
            sheet_tp=raw(r,'TP10_Hit'); sheet_md=col(r,'MaxDrop%')
            sheet_tp_b=istrue(sheet_tp)
            verdict='AGREE' if (sheet_tp_b == (rc_tp==1)) else '*** DISAGREE ***'
            if verdict=='AGREE': agree+=1
            else: disagree+=1
            print(f"  {tk:<8}{sd:<12}{str(sheet_tp):>11}{str(rc_tp):>12}{str(sheet_md):>11}{str(rc_md):>12}  {verdict}")
        except Exception as e:
            print(f"  {tk:<8}{sd:<12}  ERROR: {e}"); err+=1
    print(f"\n  SUMMARY: agree={agree}  disagree={disagree}  errors={err}")
    print(f"  >>> If disagree is HIGH: sheet data is STALE/CORRUPT, code is fine (H1/H2).")
    print(f"  >>> If agree is HIGH: code reproduces the 0 — definitions differ or live bug (H3/H4).")

print("\n=== INVESTIGATION DONE ===")
