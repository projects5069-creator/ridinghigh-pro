import sys, json, math, time, os
SNAP="post_analysis_snapshot.json"

# ===== STAGE A: load from Sheets ONCE, save to local JSON =====
if os.path.exists(SNAP):
    print(f"✓ snapshot already exists ({SNAP}) — loading from disk, ZERO Sheets calls")
    data=json.load(open(SNAP))
    header=data['header']; all_rows=data['rows']
else:
    print("→ no snapshot — reading Sheets ONCE...")
    import gspread
    from google.oauth2.service_account import Credentials
    cfg=json.load(open('sheets_config.json'))
    creds=Credentials.from_service_account_file('google_credentials.json',scopes=['https://www.googleapis.com/auth/spreadsheets'])
    gc=gspread.authorize(creds)
    all_rows=[];header=None
    for month in cfg:
        sid=cfg[month].get('post_analysis')
        if not sid: continue
        ok=False
        for a in range(6):
            try:
                vals=gc.open_by_key(sid).sheet1.get_all_values()
                if not vals: ok=True; break
                if header is None: header=vals[0]
                for r in vals[1:]:
                    if r and any(x.strip() for x in r): all_rows.append(r)
                print(f"  {month}: OK"); ok=True; break
            except Exception as e:
                w=30*(a+1); print(f"  {month} 429 attempt {a+1} — wait {w}s"); time.sleep(w)
        if not ok:
            print(f"  ✗ {month} FAILED after all retries")
        time.sleep(20)
    if header is None:
        print("✗ NO DATA — quota still blocked. Wait 10+ min and retry."); sys.exit(1)
    json.dump({'header':header,'rows':all_rows}, open(SNAP,'w'))
    print(f"✓ snapshot saved: {SNAP} ({len(all_rows)} rows) — future runs need ZERO Sheets calls")

# ===== STAGE B: backtest on local data =====
print("\n"+"="*60)
print("  TP/SL BACKTEST (from local snapshot)")
print("="*60)
idx={h.strip():i for i,h in enumerate(header)}
def col(r,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(r): return d
    v=r[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if(math.isnan(f) or math.isinf(f)) else f
    except: return None
def is_full(r): return all(fnum(col(r,f"D{i}_Low")) is not None for i in range(1,6))
fully=[r for r in all_rows if is_full(r) and fnum(col(r,'ScanPrice'))]
print(f"total rows: {len(all_rows)} | fully-settled: {len(fully)}")

def simulate(r,tp_pct,sl_pct):
    sp=fnum(col(r,'ScanPrice'))
    tpx=sp*(1-tp_pct/100.0); slx=sp*(1+sl_pct/100.0)
    for i in range(1,6):
        lo=fnum(col(r,f"D{i}_Low")); hi=fnum(col(r,f"D{i}_High"))
        if lo is None or hi is None: continue
        t=lo<=tpx; s=hi>=slx
        if t and s: return 'WHIP'
        if s: return 'LOSS'
        if t: return 'WIN'
    return 'OPEN'
def pnl_open(r):
    sp=fnum(col(r,'ScanPrice')); d5=fnum(col(r,'D5_Close'))
    return (sp-d5)/sp*100.0 if (sp and d5) else None

scenarios=[(10,10),(10,12),(10,15),(10,20),(12,15),(12,20),(15,20),(15,25),(20,25),(10,999)]
print(f"\n{'TP%':>5}{'SL%':>6}{'WIN':>6}{'LOSS':>6}{'WHIP':>6}{'OPEN':>6}{'win-rate*':>11}{'avgPnL%':>10}{'totPnL%':>10}")
print("  "+"-"*60)
for tp,sl in scenarios:
    w=l=wh=op=0; ps=0.0; pn=0
    for r in fully:
        res=simulate(r,tp,sl)
        if res=='WIN': w+=1; ps+=tp; pn+=1
        elif res=='LOSS': l+=1; ps-=sl; pn+=1
        elif res=='WHIP': wh+=1
        else:
            op+=1; p=pnl_open(r)
            if p is not None: ps+=p; pn+=1
    rate=100*w/(w+l) if (w+l) else 0
    avg=ps/pn if pn else 0
    sll="∞" if sl==999 else str(sl)
    print(f"  {tp:>3}{sll:>6}{w:>6}{l:>6}{wh:>6}{op:>6}{rate:>10.1f}%{avg:>9.2f}%{ps:>9.1f}%")
print(f"\n  avgPnL%=per-trade avg (WIN=+TP, LOSS=-SL, OPEN=D5 close, WHIP excluded)")
print(f"  totPnL%=sum across all resolved trades. Before costs/borrow/slippage.")
print("\n=== DONE ===")
