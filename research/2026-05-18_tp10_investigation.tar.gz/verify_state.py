import sys, json, math
from collections import Counter
import gspread
from google.oauth2.service_account import Credentials
print("="*52)
print("  STATE VERIFICATION — what changed + true win-rate")
print("="*52)
cfg = json.load(open('sheets_config.json'))
creds = Credentials.from_service_account_file('google_credentials.json', scopes=['https://www.googleapis.com/auth/spreadsheets'])
gc = gspread.authorize(creds)
all_rows=[]; header=None
for month, sheets in cfg.items():
    sid = sheets.get('post_analysis')
    if not sid: continue
    try:
        vals = gc.open_by_key(sid).sheet1.get_all_values()
        if not vals: continue
        if header is None: header=vals[0]
        for r in vals[1:]:
            if r and any(c.strip() for c in r): all_rows.append(r)
    except Exception as e:
        print(f"  {month} ERROR: {e}")
idx={h.strip():i for i,h in enumerate(header)}
def col(row,name,d=None):
    i=idx.get(name)
    if i is None or i>=len(row): return d
    v=row[i].strip(); return v if v else d
def fnum(v):
    if v is None: return None
    s=str(v).replace('%','').replace(',','').replace('$','').strip()
    if s.lower() in ('nan','none','','#n/a','n/a','#div/0!','inf','-inf'): return None
    try:
        f=float(s); return None if (math.isnan(f) or math.isinf(f)) else f
    except: return None
def istrue(v): return str(v).strip() in ('1','TRUE','True','true','1.0')
n=len(all_rows)
print(f"\nTOTAL rows: {n}")

# === TRUE WIN-RATE NOW ===
tp=sl=whip=neither=0
md_le10=md_le10_tp0=0
for r in all_rows:
    t=istrue(col(r,'TP10_Hit')); s=istrue(col(r,'SL_Hit_D5'))
    if t and s: whip+=1
    elif t: tp+=1
    elif s: sl+=1
    else: neither+=1
    md=fnum(col(r,'MaxDrop%'))
    if md is not None and md<=-10:
        md_le10+=1
        if not t: md_le10_tp0+=1
print(f"\n--- CURRENT classification ---")
print(f"  TP only:        {tp} ({100*tp/n:.1f}%)")
print(f"  SL only:        {sl} ({100*sl/n:.1f}%)")
print(f"  WHIPSAW:        {whip} ({100*whip/n:.1f}%)")
print(f"  Neither:        {neither} ({100*neither/n:.1f}%)")
print(f"\n--- CONSISTENCY CHECK ---")
print(f"  rows MaxDrop%<=-10%:                  {md_le10}")
print(f"  of those TP10_Hit NOT set (THE BUG):  {md_le10_tp0}")
if md_le10_tp0==0:
    print(f"  >>> CONSISTENT NOW — the 104-row bug is GONE. Sheet was refreshed.")
else:
    print(f"  >>> STILL {md_le10_tp0} inconsistent rows.")

# === resolved win-rate (exclude unresolved) ===
resolved=tp+sl+whip
if resolved:
    print(f"\n--- WIN-RATE (resolved rows only, n={resolved}) ---")
    print(f"  TP10 win-rate: {100*(tp+whip)/resolved:.1f}%  (counting whipsaw as resolved-TP)")
    print(f"  TP10 win-rate: {100*tp/resolved:.1f}%  (counting whipsaw as loss)")

# === B3: live calculate_stats on a sample ===
print(f"\n--- B3: live calculate_stats vs sheet (sample of 25 resolved rows) ---")
try:
    from utils import calculate_stats
    sample=[r for r in all_rows if col(r,'D1_Low') and col(r,'ScanPrice')][:25]
    agree=disagree=err=0
    for r in sample:
        sp=fnum(col(r,'ScanPrice'))
        ohlc={f"D{i}_{k}":fnum(col(r,f"D{i}_{k}")) for i in range(1,6) for k in('Open','High','Low','Close')}
        try:
            st=calculate_stats(sp,ohlc)
            rc=st.get('TP10_Hit'); sh=istrue(col(r,'TP10_Hit'))
            if (rc==1)==sh: agree+=1
            else:
                disagree+=1
                print(f"  DISAGREE: {col(r,'Ticker')} {col(r,'ScanDate')} sheet={col(r,'TP10_Hit')} recomputed={rc} MaxDrop%={col(r,'MaxDrop%')}")
        except Exception as e:
            err+=1
    print(f"  agree={agree}  disagree={disagree}  errors={err}")
    if disagree==0 and err==0:
        print(f"  >>> Code 100% reproduces the sheet — calculate_stats is CORRECT.")
except Exception as e:
    print(f"  B3 FAIL: {e}")
print("\n=== VERIFICATION DONE ===")
